/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
var app = {
    // Application Constructor
    initialize: function() {
        this.bindEvents();
    },
    // Bind Event Listeners
    //
    // Bind any events that are required on startup. Common events are:
    // 'load', 'deviceready', 'offline', and 'online'.
    bindEvents: function() {
        document.addEventListener('deviceready', this.onDeviceReady, false);
        localStorage.setItem('deviceId',device.uuid);
    },
    // deviceready Event Handler
    //
    // The scope of 'this' is the event. In order to call the 'receivedEvent'
    // function, we must explicitly call 'app.receivedEvent(...);'
    onDeviceReady: function() {
        app.receivedEvent('deviceready');        
        localStorage.setItem('deviceId',device.uuid);
        //enabling zoom control
  		 cordova.plugins.ZoomControl.ZoomControl("true");
  		 // enabling built in zoom control
  		 cordova.plugins.ZoomControl.setBuiltInZoomControls("true");
  		 // enabling display zoom control
  		 cordova.plugins.ZoomControl.setDisplayZoomControls("true");
          	 
        /*
        window.FirebasePlugin.getToken(function(token) {
			   // save this server-side and use it to push notifications to this device
			   alert(token);
			   saveRegId(token);
			}, function(error) {
			    console.error(error);
			});
			*/
    },
    // Update DOM on a Received Event
    receivedEvent: function(id) {
        
    }
};
/*
PullToRefresh.init({
    mainElement: 'body',
    onRefresh: function(){
        // What do you want to do when the user does the pull-to-refresh gesture
        window.location.reload(); 
    }
});
*/
var THIS_DOMAIN = "http://nagpurbroadcast.com/app/";
var SITE_DOMAIN = "http://nagpurbroadcast.com/";
//var devUuID = device.uuid;
//DATA_URL, FILE_URI

$( document ).ready(function() {
	
	$(document).on("click","#capturePic",function(){
		navigator.camera.getPicture(onSuccess, onFail, { quality: 70,
		    destinationType: Camera.DestinationType.FILE_URI,
		    encodingType: Camera.EncodingType.JPEG,
		    sourceType : Camera.PictureSourceType.CAMERA,
		    targetWidth: 500,
		    saveToPhotoAlbum: true,
		});
		
	});	
	
	$(document).on("click","#uploadPic",function(){
		/*navigator.camera.getPicture(onSuccess, onFail, { quality: 70,
		    destinationType: Camera.DestinationType.FILE_URI,
		    encodingType: Camera.EncodingType.JPEG,
		    sourceType: navigator.camera.PictureSourceType.PHOTOLIBRARY,
		     
		});*/
		var imgArr = [];
		
		window.imagePicker.getPictures(
			function(results) {
				var mtIm = "";
				for (var i = 0; i < results.length; i++) {
					//alert('Image URI: ' + results[i]);
					//uploadImage(results[i]);
					mtIm += '<img src="'+results[i]+'" >';
					imgArr.push(results[i]); 
				}
				$('#mltImg').html(mtIm);
				localStorage.setItem("imgStor", JSON.stringify(imgArr));
			}, function (error) {
				console.log('Error: ' + error);
			}, {
				maximumImagesCount: 10,
				width: 500
			}
		);
		
	});
	
	$(document).on("click","#addPost",function(){
		var locImg = localStorage.getItem("imgStor");
		//alert(locImg);
		var title = $.trim($('#postTitle').val());
		var desc = $.trim($('#postDesc').val());
		var valid = true;
		if (title == "") {
			$('#error').html('Please provide title.').addClass('alert alert-danger');
			valid = false;
		}
		var ImgErr = JSON.parse(locImg);
		//alert(ImgErr.length);
		if (ImgErr.length <= 0) {
			$('#error').html('Please upload atleast one image.').addClass('alert alert-danger');
			valid = false;
		}
		
		var intvr = "";
		if (valid === true) {
			$('#ajxLoading').show();
			var imgpth = $('#imgPath').val();
			var imgNm = "";
			if (locImg) {
				var imgNmStr = "";
				if (imgpth == "") {					
					var ImgArray = JSON.parse(locImg);				
					for (var i = 0; i < ImgArray.length; i++) {
						uploadImage(ImgArray[i]);					
						imgNmStr += ImgArray[i].substr(ImgArray[i].lastIndexOf('/') + 1)+',';
					}
				}else {	
					uploadImage(imgpth);					
					imgNmStr = imgpth.substr(imgpth.lastIndexOf('/') + 1);
				}
				intvr = setInterval(function(){
					var imgNm = $('#imgName').val();
					if (imgNm != "") {
						clearInterval(intvr); createPost(title,desc,imgNmStr);
					}
				}, 3000);
				
			}else {
				//createPost(title,desc,'');
				$('#error').html('Please upload atleast one image.').addClass('alert alert-danger');
				valid = false;
			}	
			
		}	
	});
	
	$(document).on("click",".postBtn, .addIcon",function(){
		if (localStorage.getItem('userId') > 0) {
			$.mobile.changePage( $("#createPost"),{ transition: "fade"});
		}else {
			$.mobile.changePage( $("#loginPage"),{ transition: "fade"});
		}		
	});
	
	$(document).on("click","#wishlist",function(){
		checkLoginUser();
		$("#ajxLoading" ).show();
		
		
		var usId = localStorage.getItem('userId');
		
		$.ajax({
			type: "POST",
			url: THIS_DOMAIN+"getMyWishlist.php",
			data: {uId:usId},
			success: function(result)
			{	
				postStr = getPostListView(result);
				$('#myWishlist').html(postStr);	
				$("#ajxLoading" ).hide();
			},
			dataType: 'json'
		});
		$.mobile.changePage( $("#wishlistPage"),{ transition: "fade"});
	});
		
		
	$(document).on("click","#goForgotPass",function(){
		$( "#forgotPass").slideToggle('slow');
	});	
	$(document).on("click","#showSignupFrm",function(){
		$( "#signUpUsrBx").slideToggle('slow');
	});
	$(document).on("click",".serchIcon",function(){
		openSearch();
	});
	$(document).on("click",".serClose",function(){
		closeSearch();		
	});
	
	$(document).on("click",".catName",function(){		
		var catId = $(this).attr('data-id');
		var catName = $(this).text();
		//alert(catName);
		$('#postCatId').val(catId);
		$('#postCatName').val(catName);
		$.mobile.changePage( $("#catPostPage"),{ transition: "fade"});
	});	
		
	$(document).on("click","#userLogin",function(){
		$('#loginError').html('');	
		$("#ajxLoading" ).show();
		var lemail = $('#email').val();
		var lpass = $('#password').val();
		var flg = true;
		if (lemail == "" || lpass == "") {
			$('#loginError').html('<div style="color:red;margin-bottom:10px;">Please provide valid login detail</div>');
			$("#ajxLoading" ).hide();
			flg = false;
		}	
		if (flg === true) {
			$.ajax({
				type: "POST",
				url: THIS_DOMAIN+"userLogin.php",
				data: {email:lemail,pass:lpass},
				success: function(succ)
				{	
					//alert(succ);	
					if (succ.status == "ok") {
						localStorage.setItem('email',succ.emailId);
						localStorage.setItem('fullName',succ.fullName);
						localStorage.setItem('userId',succ.userId);			
						checkLoginUser();			
						$.mobile.changePage( $("#homePage"),{ transition: "fade"});
					}else {
						$('#loginError').html('<div style="color:red;margin-bottom:10px;">Invalid login detail</div>');
					}
					$("#ajxLoading" ).hide();	
				},
				dataType: 'json'
			});
		}
	});
	
	$(document).on("click","#userSignUp",function(){
		$('#signUpError').html('');
		$("#ajxLoading" ).show();	
		var rgusername = $('#userNameRg').val();
		var rgEmail = $('#emailRg').val();
		var rgPass = $('#passwordRg').val();
		var rgRePass = $('#reTpasswordRg').val();
		var rgPhoneNo = $('#phoneNoRg').val();
		//alert(rgPass);
		var flg = true;
		if (rgusername == "" || rgPass == "" || rgRePass == "" || rgPhoneNo == "") {
			$('#signUpError').html('<div style="color:red;margin-bottom:10px;">All fields are compulsory.</div>');
			flg = false;
			$("#ajxLoading" ).hide();
		}
		if (rgPass != rgRePass) {
			$('#signUpError').html('<div style="color:red;margin-bottom:10px;">Password mis-match.</div>');
			flg = false;
			$("#ajxLoading" ).hide();			
		}
		
		if (rgEmail != "") {
			flg = false;
			$.ajax({
				type: "POST",
				url: THIS_DOMAIN+"checkUserNameEmail.php",
				data: {userEm:rgEmail, userPh:rgPhoneNo},
				success: function(resp)
				{			
					//alert(resp);
					if (resp.error != '') {
						$('#signUpError').html('<div style="color:red;margin-bottom:10px;">'+resp.error+'</div>');
						$("#ajxLoading" ).hide();
					}else {
						flg = true;	
					}
				},
				dataType: 'json',
				async: false
			});
		}		
		
		if (flg === true) {	
			$.ajax({
				type: "POST",
				url: THIS_DOMAIN+"userSignup.php",
				data: {usnm:rgusername,userEm:rgEmail,pass:rgPass,userPh:rgPhoneNo},
				success: function(resp)
				{	
					
					if (resp > 0) {
						localStorage.setItem('email',rgEmail);
						localStorage.setItem('fullName',rgusername);
						localStorage.setItem('userId',resp);
						checkLoginUser();
						$.mobile.changePage( $("#homePage"),{ transition: "fade"});
						$("#ajxLoading" ).hide();
					}
						
				},
				dataType: 'json',
				async: false
			});
		}	
	});
	
	$(document).on("click","#forgotPassBrn",function(){
		var rgEmail = $('#forgotEmail').val();
		$("#ajxLoading" ).show();
		var flg = true;
		if (rgEmail == "") {
			$('#forpassError').html('<div style="color:red;margin-bottom:10px;">Please provide valid email.</div>');
			flg = false;	
			$("#ajxLoading" ).hide();
		}
		if (flg === true) {	
			$.ajax({
				type: "POST",
				url: THIS_DOMAIN+"forgotPassword.php",
				data: {userEm:rgEmail},
				success: function(resp)
				{	
					
					if (resp == 'Error') {
						$('#forpassError').html('<div style="color:red;margin-bottom:10px;">Email does not exist with us.</div>');
					}else if (resp == 'ErrVl') {
						$('#forpassError').html('<div style="color:red;margin-bottom:10px;">Invalid email.</div>');
					}else {
						$('#forpassError').html('<div style="color:green;margin-bottom:10px;">Please check your inbox for login details.</div>');	
					}
					$("#ajxLoading" ).hide();			
				},
				dataType: 'json'
			});
		}
		
	});
	$(document).on("click","#searchBtn",function(){
		var sch = $.trim($('#sq').val());
		if (sch != "") {
			getSearchResult(sch);
			$.mobile.changePage( $("#searchPage"),{ transition: "fade"});
			
		}	
	});
	//search on enter key
	$(document).on("keypress","#sq",function(e){	
		var key = e.which;
	  	if(key == 13){
	    	var sch = $.trim($('#sq').val());
			if (sch != "") {
				getSearchResult(sch);
				$.mobile.changePage( $("#searchPage"),{ transition: "fade"});
			}  
	  	}
	}); 
	
	$(document).on("click",".addLike",function(){		
		var lkId = $(this).attr('id');
		$('#'+lkId+' span').html('<i class="fa fa-spinner fa-pulse fa-fw"></i>');
		var poId = lkId.replace("addLike-", "");		
		$(this).attr('data-id', 'pstliks-'+poId);
		var usId = localStorage.getItem('userId');
		var deviceId = localStorage.getItem('deviceId');
		//alert(deviceId);
		$.ajax({
			type: "POST",
			url: THIS_DOMAIN+"addLikeDislike.php",
			data: {usId:usId, devId:deviceId,pId:poId, callfor:'like'},
			success: function(result)
			{
				
				if (result.usLkCont == 1) {
					//$("[data-id='pstliks-"+poId+"']").first().html('<i class="fa fa-thumbs-up" aria-hidden="true"></i>');
					$("[data-id='pstliks-"+poId+"'] i:first-child").removeClass('fa-thumbs-o-up').addClass('fa-thumbs-up');
					$("[data-id='pstliks-"+poId+"']").css( "color", "#1595fb" );					
					$("[data-id='pstliks-"+poId+"']").next().css( "color", "#000" );
				}else {
					$("[data-id='pstliks-"+poId+"'] i:first-child").removeClass('fa-thumbs-up').addClass('fa-thumbs-o-up');
					$("[data-id='pstliks-"+poId+"']").css( "color", "#000" );
				}
				
				var lkct = result.likeCnt;
				if (lkct == 0) {
					lkct = "";
				}	
				var dsct = result.disLkCnt;
				if (dsct == 0) {
					dsct = "";
				}
				$('#'+lkId+' span').html(lkct);
				$('#addDislk-'+poId+' span').html(dsct);
						
			},
			dataType: 'json',
		});
	});
	
	$(document).on("tap","#myPost",function(){
		$('#postUsId').val(localStorage.getItem('userId'));
		$('#psUserNM').val(localStorage.getItem('fullName'));
		$.mobile.changePage( $("#mypostPage"),{ transition: "fade"});
	});
	
		
	$(document).on("tap","#myInbox",function(){
		$('#inboxUsId').val(localStorage.getItem('userId'));
		$('#inboxUserNM').val(localStorage.getItem('fullName'));
		$.mobile.changePage( $("#inboxPage"),{ transition: "fade"});
	});
	
	
	$(document).on("tap",".userPost",function(){
		var psuId = $(this).attr('data-id');
		var psuName = $(this).attr('data-name');
		$('#postUsId').val(psuId);
		$('#psUserNM').val(psuName);
		$.mobile.changePage( $("#mypostPage"),{ transition: "fade"});
	});	
	
	$(document).on("tap","#chgPassLink",function(){
		$.mobile.changePage( $("#changePassPage"),{ transition: "fade"});
	});	
	$(document).on("tap",".comment",function(){
		$('html,body').animate({scrollTop: $("#pstCmtbx").offset().top},'slow');
	});
	
	$(document).on("click","#changePassBtn",function(){
		$('#passErr').html('');	
		$("#ajxLoading" ).show();
		var pass = $('#newPassword').val();
		var retPass = $('#reEntpass').val();
		var flg = true;
		if (pass == "" || retPass == "") {
			$('#passErr').html('<div style="color:red;margin-bottom:10px;">Both fields are compulsory</div>');
			$("#ajxLoading" ).hide();
			flg = false;
		}	
		if (pass != retPass) {
			$('#passErr').html('<div style="color:red;margin-bottom:10px;">Password miss-match</div>');
			$("#ajxLoading" ).hide();
			flg = false;
		}	
		if (flg === true) {
			$.ajax({
				type: "POST",
				url: THIS_DOMAIN+"changePassword.php",
				data: {pass:pass,uId:localStorage.getItem('userId')},
				success: function(succ)
				{							
					if (succ.status == "ok") {
						$('#passErr').html('<div style="color:green;margin-bottom:10px;">Password has been changed successfully.</div>');
					}else {
						$('#passErr').html('<div style="color:red;margin-bottom:10px;">Something wrong, please try again</div>');
					}
					$('#newPassword').val('');
					$('#reEntpass').val('');
					$("#ajxLoading" ).hide();	
				},
				dataType: 'json'
			});
		}
	});
	
	/*$(window).scroll(function() {
		
	  if ($(window).scrollTop() == $(document).height() - $(window).height()) {
	    alert("End of Page");
	  }else if ($(window).scrollTop() <= 0) {
	  	 alert("top of Page");
	  }	
	});
	
	$(document).scroll(function(){
	if ($(this).scrollTop() > 100) {			
		$('.searchBx').css({"top": "0px",'position':'fixed','background':'#166bb3'});
	} else {
		$('.searchBx').css({"top": "0px",'position':'relative','background':'#166bb3'});
	}	
});	
	*/
	var lastScrollTop = 0;
	$(document).scroll(function(event){
	   var st = $(this).scrollTop();
	   if (st > lastScrollTop){
	      $('.appHeader').removeClass('shrink');	      
	   } else {
	      $('.appHeader').addClass('shrink');
	   }
	   lastScrollTop = st;
	});
})//end ready

$(document).on("pageshow","#homePage",function(){
	//alert(localStorage.getItem('userId'))
	checkLoginUser();
	$('#ajxLoading').show();
	getPostList('');
	
	$(document).scroll(function(){		
		if ($(window).scrollTop() + $(window).height() > $(document).height() - 200) {
			
			if($('#isHombusy').val() == 'no' ){
				//alert('here');
				//$('.lmLoding').show();																							
				getPostList('loadmore');
			}
		}
	});
	
});

$(document).on("pageshow","#mypostPage",function(){
	var pusId = $('#postUsId').val();
	
	checkLoginUser();
	$('#ajxLoading').show();
	getMyAllPostList(pusId, '');
	
	$(document).scroll(function(){		
		if ($(window).scrollTop() + $(window).height() > $(document).height() - 200) {
			
			if($('#isMyPtbusy').val() == 'no' ){
				$('.lmLoding').show();																							
				getMyAllPostList(pusId, 'loadmore');
			}
		}
	});
});

$(document).on("pageshow","#inboxPage",function(){
	var pusId = $('#inboxUsId').val();
	checkLoginUser();
	$('#ajxLoading').show();
	$('#myInboxData').html('');
	getInbox(pusId, '');
	
	$(document).scroll(function(){		
		if ($(window).scrollTop() + $(window).height() > $(document).height() - 200) {
			
			if($('#isMyPtbusy').val() == 'no' ){
				$('.lmLoding').show();
				getInbox(pusId, 'loadmore');
			}
		}
	});
});


$(document).on("pageshow","#catPostPage",function(){
	var catId = $('#postCatId').val();
	
	$('#ajxLoading').show();
	getCatAllPostList(catId, '');
	
	$(document).scroll(function(){		
		if ($(window).scrollTop() + $(window).height() > $(document).height() - 200) {
			
			if($('#isCatPtbusy').val() == 'no' ){
				$('.lmLoding').show();																							
				getCatAllPostList(catId, 'loadmore');
			}
		}
	});
});

$(document).on("pageshow","#searchPage",function(){
	closeSearch();
	var sch = $.trim($('#sq').val());
	if (sch != "") {
		$('#ajxLoading').show();
		getSearchResult(sch, '');
	}
		
	$(document).scroll(function(){		
		if ($(window).scrollTop() + $(window).height() > $(document).height() - 50) {			
			if($('#isSerchbusy').val() == 'no' ){				
				$('.lmLoding').show();										
				getSearchResult(sch, 'loadmore');
			}
		}
	});
});


$(document).on("pageshow","#logoutPage",function(){
				
	$('#ajxLoading').show();
	localStorage.removeItem('email');
	localStorage.removeItem('fullName');
	localStorage.removeItem('userId');	
	var louT = '<h4>You have successfully logged out!</h4>If you want to login <a href="#loginPage" data-transition="fade">click here</a>';	
	$('#logoutTxt').html(louT);
	$('#ajxLoading').hide();
	checkLoginUser();
});

$(document).on("pageshow","#createPost",function(){
	
	var catStr = "";
	$.ajax({
		type: "POST",
		url: THIS_DOMAIN+"getAllCategory.php",		
		success: function(result)
		{
			//alert(result)
			$.each( result, function( i, item ) {
				catStr += '<option value="'+item.catId+'">'+item.catName+'</option>';
			})
			
			$('#category').html(catStr);
			
		},
		dataType: 'json',		
	});
});

$(document).on("pageshow","#postDetail",function(){	
	
});


$(document).on("pageshow","#categoryPage",function(){
	
	var catStr = "";	
	$('#catStr').html(catStr);
	$('#ajxLoading').show();
	
	$.ajax({
		type: "POST",
		url: THIS_DOMAIN+"getShopCategory.php",		
		success: function(result)
		{
			//alert(result)
			$('#catStr').html(result);			
			
			$('#ajxLoading').hide();
			/*
			$.each( result, function( i, item ) {
				catStr += '<option value="'+item.catId+'">'+item.catName+'</option>';
			})
			$('#category').html(catStr);
			*/
			
		},
		dataType: 'html',		
	});
});

function getPostList(clfr) {
	$('#isHombusy').val('yes');
	if (clfr != "loadmore") {
		$('#postList').html('');
		$('#homlmt').val(0);
		pgLim = $('#homlmt').val();
	}else {
		var pgLim = Number($('#homlmt').val()) + 10;
		$('#homlmt').val(pgLim);	
	}	
	var deviceId = localStorage.getItem('deviceId');	
	var userId = localStorage.getItem('userId');
		
	var postStr = "";
	
	$.ajax({
		type: "POST",
		url: THIS_DOMAIN+"getPostForHome.php",
		data: {lmt:pgLim, devId:deviceId, uId:userId},
		success: function(result)
		{
			//alert(result)
			postStr = getPostListView(result);
			
			$('#ajxLoading').hide();
			$('.lmLoding').hide();
			if (clfr != "loadmore") {			
				$('#postList').html(postStr);	
				
			}else { 			
				$('#postList').append(postStr);
				
			}
			$('#isHombusy').val('no');
		},
		dataType: 'json',		
	});
}

function getSearchResult(sText, clfr) {	
	$('#isSerchbusy').val('yes');
	var searchStr = "";
	if (clfr != "loadmore") {
		var limt = 0;	
		$('#searchText').html('');
		searchStr += '<div data-role="main" class="ui-content"><h4>Search results for *'+sText+'*</h4><div class="space10"></div></div>';
	}else {
		var limt = $('#serLmt').val();
	}	
	var deviceId = localStorage.getItem('deviceId');
	$.ajax({
		type: "POST",
		url: THIS_DOMAIN+"getPostForSearch.php",
		data: {stxt:sText, lmt:limt, devId:deviceId},
		success: function(result)
		{
			searchStr += getPostListView(result);
			
			$('#ajxLoading').hide();			
			$('.lmLoding').hide();
			if (clfr != "loadmore") {			
				$('#searchText').html(searchStr); 
				
			}else { 			
				$('#searchText').append(searchStr);
				var pgLim = Number(limt) + 10;
				$('#serLmt').val(pgLim);
			}
			$('#isSerchbusy').val('no');			
		},
		dataType: 'json',
	});
}

function getMyAllPostList(psUId,clfr) {
	$('#isMyPtbusy').val('yes');
	if (clfr != "loadmore") {
		$('#myAllPost').html('');
		$('#myPtLmt').val(0);
		pgLim = $('#myPtLmt').val();
		var postStr = '<div data-role="main" class="ui-content"><h4>'+$('#psUserNM').val()+'\'\s posts</h4></div>';
	}else {
		var pgLim = Number($('#myPtLmt').val()) + 10;
		$('#myPtLmt').val(pgLim);
		var postStr = '';	
	}	
	var deviceId = localStorage.getItem('deviceId');	
	
	$.ajax({
		type: "POST",
		url: THIS_DOMAIN+"getAllMyPosts.php",
		data: {lmt:pgLim, devId:deviceId, usId:psUId},
		success: function(result)
		{
			//alert(result)
			postStr += getPostListView(result);
			
			$('#ajxLoading').hide();
			$('.lmLoding').hide();
			if (clfr != "loadmore") {			
				$('#myAllPost').html(postStr);	
				
			}else { 			
				$('#myAllPost').append(postStr);
				
			}
			$('#isMyPtbusy').val('no');
		},
		dataType: 'json',		
	});
}

function getInbox(psUId,clfr) {
	$('#isInboxbusy').val('yes');
	var deviceId = localStorage.getItem('deviceId');
	
	
	if (clfr != "loadmore") {
		$('#myInboxData').html('');
		$('#myInboxLmt').val(0);
		pgLim = $('#myInboxLmt').val();
		var inbox = '<div data-role="main" class="ui-content"><h4>Inbox</h4></div>';
	}else {
		var pgLim = Number($('#myInboxLmt').val()) + 10;
		$('#myInboxLmt').val(pgLim);
		var inbox = '';
	}	
	
	$.ajax({
		type: "POST",
		url: THIS_DOMAIN+"getInbox.php",
		data: {lmt:pgLim,devId:deviceId, usId:psUId},
		success: function(result)
		{
			
			if(result != ''){
				$.each(result, function( i, item ) {
				inbox +='<a href="#" onclick="getMessage('+item.senderId+')" style="color:inherit;font-weight:normal;"><div class="row" style="border:1px solid #ddd;margin-left: 15px;margin-right: 15px;padding: 10px 0px;"><div class="col-xs-2" style="color: #49e1b5;"><i class="fa fa-3x fa-envelope" aria-hidden="true"></i></div><div class="col-xs-8"><div class="col-xs-12"><strong>'+item.fullName+'</strong></div>';
					inbox +='<div class="col-xs-12"><div class="msgDesc">'+item.message+'</div></div></div><div class="col-xs-2 text-right"><i class="fa fa-3x fa-chevron-right" style="color: #49e1b5;" aria-hidden="true"></i></div></div></a><div class="space10"></div>';
				});
			}
			
			$('#ajxLoading').hide();
			$('.lmLoding').hide();
			
			if (clfr != "loadmore") {
				$('#myInboxData').html(inbox);
			} else {
				$('#myInboxData').append(inbox);
			}
			
			$('#ajxLoading').hide();
			$('.lmLoding').hide();
			$('#isMyPtbusy').val('no');
		},
		dataType: 'json',		
	});	
}	

function getMessage(senderId) {
	checkLoginUser();
	$('#myMsgLmt').val(10);
	var pusId = $('#inboxUsId').val();
	checkLoginUser();
	$('#ajxLoading').show();
	$('#messageDetaildata').html('');
	
	$('#msgUsId').val(localStorage.getItem('userId'));
	$('#msgUserNM').val(localStorage.getItem('fullName'));
	$.mobile.changePage( $("#messageDetail"),{ transition: "fade"});
	
	var usId = localStorage.getItem('userId');
	var lmt = 0;
	$.ajax({
		type: "POST",
		url: THIS_DOMAIN+"getMessageDetail.php",
		data: {senderId:senderId,usId:usId,lmt:lmt},
		success: function(result)
		{
			var inbox = '';
			$('#ajxLoading').hide();
			$('.lmLoding').hide();
			
			if(result != ''){
			var inbox = '<div data-role="main" class="ui-content"><h4>Conversation Between you & '+result[0]['otherUser']+'</h4></div><div style="height:10px;clear:both;"></div><div class="col-xs-12"><button class="form-control loadMoreMsgDtl" onclick="loadMoreMsgDtl('+senderId+')" style="text-align:center;">Load More</button></div><div style="height:10px;clear:both;"></div><div id="oldMessage"></div>';
				$.each(result, function(i,item) {
				inbox +='<div class="row" style="border:1px solid #ddd;margin-left: 15px;margin-right: 15px;padding: 10px 0px;"><div class="col-xs-12" style="color: #49e1b5;"><strong style="vertical-align: super;"><a class="userPost" data-id="'+item.userId+'" data-name="'+item.fullName+'">'+item.fullName+'</a></strong></div><div class="space10"></div>';
					inbox +='<div class="col-xs-12"><div class="msgDesc">'+item.message+'</div></div></div><div class="space10"></div>';
				});
				inbox +='<div id="replyDiv"></div><div class="space10"></div><div class="col-xs-12"><form method="post" name="replyMsgFrm" id="replyMsgFrm"><div class="msg-txt replyTxt"><textarea rows="5" placeholder="Message" class="form-control" id="replyMsg" name="replyMsg"></textarea></div><input id="receiverId" name="receiverId" class="yellow_button" value="'+result[0]['receiverId']+'" type="hidden"><input id="sessionId" name="sessionId" class="yellow_button" value="'+result[0]['userId']+'" type="hidden"><input id="fullName" name="fullName" class="yellow_button" value="'+result[0]['fullName']+'" type="hidden"><div style="height:5px;clear:both;"></div><div class="msg-btn"><input id="replyBtn" name="replyBtn" class="btn btn-success orgBtn" onclick="pMsg()" value="Reply" type="button"></div><div class="msg-btn loaderload" style="display:none;">Loading...</div></form></div><div style="height:10px;clear:both;"></div>';
			}
			$('#messageDetaildata').html(inbox);
		},
		dataType: 'json',		
	});
}

function loadMoreMsgDtl(senderId) {
	checkLoginUser();
	var pusId = $('#inboxUsId').val();
	var lmt =  Number($('#myMsgLmt').val()) + 10;
	
	checkLoginUser();
	$('#ajxLoading').show();
	$('#msgUsId').val(localStorage.getItem('userId'));
	$('#msgUserNM').val(localStorage.getItem('fullName'));
	$.mobile.changePage( $("#messageDetail"),{ transition: "fade"});
	
	var usId = localStorage.getItem('userId');
	
	$.ajax({
		type: "POST",
		url: THIS_DOMAIN+"getMessageDetail.php",
		data: {senderId:senderId,usId:usId,lmt:lmt},
		success: function(result)
		{
			var inbox = '';
			//alert(result);
			//console.log(result);
			if(result != ''){
				$.each(result, function(i,item) {
				inbox +='<div class="row" style="border:1px solid #ddd;margin-left: 15px;margin-right: 15px;padding: 10px 0px;"><div class="col-xs-12" style="color: #49e1b5;"><strong style="vertical-align: super;"><a class="userPost" data-id="'+item.userId+'" data-name="'+item.fullName+'">'+item.fullName+'</a></strong></div><div class="space10"></div>';
					inbox +='<div class="col-xs-12"><div class="msgDesc">'+item.message+'</div></div></div><div class="space10"></div>';
				});
				var pgLim = Number($('#myMsgLmt').val()) + 10;
				$('#myMsgLmt').val(pgLim);
			}else{
			$('.loadMoreMsgDtl').css({'display':'none'});
			}
			$('#ajxLoading').hide();
			$('#oldMessage').append(inbox);
		},
		dataType: 'json',		
	});
}



function getCatAllPostList(psUId,clfr) {
	$('#isCatPtbusy').val('yes');
	if (clfr != "loadmore") {
		$('#catAllPost').html('');
		$('#catPtLmt').val(0);
		pgLim = $('#catPtLmt').val();
		var postStr = '<div data-role="main" class="ui-content"><h4>'+$('#postCatName').val()+' posts</h4></div>';
	}else {
		var pgLim = Number($('#catPtLmt').val()) + 10;
		$('#catPtLmt').val(pgLim);
		var postStr = '';	
	}
	var deviceId = localStorage.getItem('deviceId');	
	var userId = localStorage.getItem('userId');	
	
	$.ajax({
		type: "POST",
		url: THIS_DOMAIN+"getCatAllPosts.php",
		data: {lmt:pgLim, devId:deviceId, cpId:psUId,clf:'ajx',uId:userId},
		success: function(result)
		{
			//alert(result)
			postStr += getPostListView(result);
			
			$('#ajxLoading').hide();			
			if (clfr != "loadmore") {			
				$('#catAllPost').html(postStr);	
				
			}else { 			
				$('#catAllPost').append(postStr);
				
			}
			$('#isCatPtbusy').val('no');
		},
		dataType: 'json',		
	});
}

function getPostListView(resp) {
	
	var pstList = "";
	if (resp != "") {
		var ImgSh = "";
		$.each( resp, function( i, item ) {
			ImgSh = item.image;
			if (ImgSh != "") {
			var imArr = ImgSh.split(",");
			}
			var lik = "";var dslik = ""; var dlkcls = ""; var lkcls = "";var psComnt = "";
			
			if (item.pLike > 0) {lik = item.pLike;}
			if (item.disLike > 0) {dslik = item.disLike;}
			if (item.cmtCount > 0) {psComnt = item.cmtCount;}
			var lkthmb = '<i class="fa fa-thumbs-o-up" aria-hidden="true"></i>';
			if (item.isLike > 0) {
				lkcls = 'lkFtCor';
				lkthmb = '<i class="fa fa-thumbs-up" aria-hidden="true"></i>';
			}
			var wishlist = '';			
			if(localStorage.getItem('userId') > 0 && localStorage.getItem('userId') != item.userId){
				var fa = '';
				if(item.isWish > 0){fa='fa-heart';}else{fa='fa-heart-o';}
			wishlist = '<a  href="#" onclick="AddWishlist('+localStorage.getItem('userId')+','+item.pId+')"><i class="fa '+fa+' wishlist'+item.pId+'" aria-hidden="true"></i></a>';
			}
			
			pstList += '<div class="cardView cardView'+item.pId+'"><div class="cmnpad"><div class="pull-right">'+wishlist+'</div><a class="userPost" data-id="'+item.userId+'" data-name="'+item.fullName+'">'+item.fullName+'</a><div>'+item.addDate+'</div></div>';
			pstList += '<div onclick="getPostDetail('+item.pId+')"><div class="psImg"><img src="'+SITE_DOMAIN+'postImages/'+item.imgPath+'/'+imArr[0]+'" /></div>';
			
			
			pstList += '<div class="cmnpad"><div class="prPrice"><i class="fa fa-inr"></i>'+item.price+'</div><div><strong>'+item.title+'</strong></div>';
			pstList += '<div>'+item.description+'</div></div></div>';
			pstList += '<div class="cmnpad"><div class="likDis addLike '+lkcls+'" id="addLike-'+item.pId+'">'+lkthmb+' <span>'+lik+'</span> Like</div><div class="comment" id="comment-'+item.pId+'" onclick="goTocomment('+item.pId+')"><i class="fa fa-comments-o" aria-hidden="true"></i> '+psComnt+' Comment</div><div class="clearfix"></div></div>';
			pstList += '</div>';
			});
	}
	
	return pstList;
}

function getPostListViewOldNotuse(resp) {
	
	var pstList = "";
	if (resp != "") {
		var ImgSh = "";
		$.each( resp, function( i, item ) {
			pstList += '<div class="postUsr psuli">Posted By: <a class="userPost" data-id="'+item.userId+'" data-name="'+item.fullName+'">'+item.fullName+'</a> on '+item.addDate+' </div><div onclick="getPostDetail('+item.pId+')"><div data-role="main" class="ui-content"></div><div class="space10"></div><div class="imgbx">';
			ImgSh = item.image;
			if (ImgSh != "") {
			var imArr = ImgSh.split(",");
			
			for (var k = 0; k < imArr.length; k++) {
				if (imArr.length >= 5) {
					if (k==0) {
					pstList += '<div class="imlf5"><div class="imlftp5" style="background:url('+SITE_DOMAIN+'postImages/'+item.imgPath+'/'+imArr[k]+')"></div>';
					}							
					if (k==1) {
						pstList += '<div class="imlfbt5" style="background:url('+SITE_DOMAIN+'postImages/'+item.imgPath+'/'+imArr[k]+')"></div></div><div class="imrt5">';
					}
					if (k==2) {
						pstList += '<div class="imrttp5" style="background:url('+SITE_DOMAIN+'postImages/'+item.imgPath+'/'+imArr[k]+')"></div>';
					}
					if (k==3) {
						pstList += '<div class="imrtmd5" style="background:url('+SITE_DOMAIN+'postImages/'+item.imgPath+'/'+imArr[k]+')"></div>';
					}
					if (k==4) {
						pstList += '<div class="imrtbt5"  style="background:url('+SITE_DOMAIN+'postImages/'+item.imgPath+'/'+imArr[k]+')">';
						if ((imArr.length - 5) > 0) {
						pstList += '<div class="cntMrImg">+'+(imArr.length - 5)+'</div>';
						}
						pstList += '</div></div><div class="clearfix"></div>';
					}							
				}
				if (imArr.length == 4) {
					if (k==0) {
					pstList += '<div class="imtp4" style="background:url('+SITE_DOMAIN+'postImages/'+item.imgPath+'/'+imArr[k]+')"></div><div>';
					}							
					if (k==1) {
						pstList += '<div class="imbtlf4" style="background:url('+SITE_DOMAIN+'postImages/'+item.imgPath+'/'+imArr[k]+')"></div>';
					}
					if (k==2) {
						pstList += '<div class="imbtmd4" style="background:url('+SITE_DOMAIN+'postImages/'+item.imgPath+'/'+imArr[k]+')"></div>';
					}							
					if (k==3) {
						pstList += '<div class="imbtrt4" style="background:url('+SITE_DOMAIN+'postImages/'+item.imgPath+'/'+imArr[k]+')">';						
						pstList += '</div></div><div class="clearfix"></div>';
					}
				}				
				
				if (imArr.length == 3) {
					if (k==0) {
					pstList += '<div class="fsImg3" style="background:url('+SITE_DOMAIN+'postImages/'+item.imgPath+'/'+imArr[k]+')"></div><div class="sndImg3">';
					}							
					if (k==1) {
						pstList += '<div class="tpImg3" style="background:url('+SITE_DOMAIN+'postImages/'+item.imgPath+'/'+imArr[k]+')"></div>';
					}
					if (k==2) {
						pstList += '<div class="btImg3"  style="background:url('+SITE_DOMAIN+'postImages/'+item.imgPath+'/'+imArr[k]+')">';
						if ((imArr.length - 3) > 0) {
						pstList += '<div class="cntMrImg">+'+(imArr.length - 3)+'</div>';
						}
						pstList += '</div></div><div class="clearfix"></div>';
					}							
				}
				if (imArr.length == 2) {
					if (k==0) {
						pstList += '<div class="fsImg2" style="background:url('+SITE_DOMAIN+'postImages/'+item.imgPath+'/'+imArr[k]+')"></div>';	
					}	
					if (k==1) {
						pstList += '<div class="fsImg2R" style="background:url('+SITE_DOMAIN+'postImages/'+item.imgPath+'/'+imArr[k]+')"></div><div class="clearfix"></div>';	
					}
				}
				if (imArr.length == 1) {
					pstList += '<div class="fsImg1" style="background:url('+SITE_DOMAIN+'postImages/'+item.imgPath+'/'+imArr[k]+')"></div>';
				}	
				
				if (k >= 5) {
					break;
				}	
			}	
			}
			var lik = "";var dslik = ""; var dlkcls = ""; var lkcls = "";var psComnt = "";
			
			if (item.pLike > 0) {lik = item.pLike;}
			if (item.disLike > 0) {dslik = item.disLike;}
			if (item.cmtCount > 0) {psComnt = item.cmtCount;}
			
			if (item.isLike > 0) {lkcls = 'lkFtCor'}
			if (item.isDisLike > 0) {dlkcls = 'lkFtCor'}
			
			pstList += '<div class="clearfix"></div></div></div><div data-role="main" class="ui-content"><div onclick="getPostDetail('+item.pId+')"><div class="postTitle">'+item.title+'</div><div class="space10"></div><div class="ptDesc">'+item.description+'</div></div><div class="shrIcn"><div class="likDis addLike '+lkcls+'" id="addLike-'+item.pId+'"><i class="fa fa-thumbs-o-up" aria-hidden="true"></i> Like<br><span>'+lik+'</span></div><div class="comment" id="comment-'+item.pId+'" onclick="goTocomment('+item.pId+')"><i class="fa fa-comments-o" aria-hidden="true"></i> Comments<br><span>'+psComnt+'</span></div><div class="clearfix"></div></div></div><div class="divider"></div>';
		});
	}
	
	return pstList;
}		

function createPost(title,desc,imgName) {
	var usrId = localStorage.getItem('userId');	
	var cat = $('#category').val();
	var price = $('#postPrice').val();
	var address = $('#address').val();
	var postData = {title:title, desc:desc, imgName:imgName, uId:usrId, cat:cat, price:price, address:address} 
	
	
	$.ajax({
		type: "POST",
		url: THIS_DOMAIN+"addPost.php",
		data: postData,
		success: function(resp)
		{
			//alert(resp)
			$('.frminp').val('');
			$('#myImage').attr('src', '');
			$('#mltImg').html('');		
			imgArr = [];				
			localStorage.removeItem('imgStor');
			getPostDetail(resp);
			
		},
		dataType: 'json',
		//async: false
	});
}	

function openMsgModal() {
	if (localStorage.getItem('userId') > 0) {
		$("#sendMsg").modal('show');
	}else {
		//$('.loginBtn').html('Login').attr('href', '#loginPage');
		$('.postDetail').css('display','none');
		$.mobile.changePage( $("#loginPage"),{ transition: "fade"});
	}
}

function getPostDetail(pId) {
	$('#ajxLoading').show();
	var ptInfo = "";
	$('#postInfo').html('');
	var deviceId = localStorage.getItem('deviceId');
	var uId = localStorage.getItem('userId');
	//alert(deviceId);
	$.ajax({
		type: "POST",
		url: THIS_DOMAIN+"getPostdetails.php",
		data: {pId:pId, devId:deviceId,uId:uId},
		success: function(resp)
		{	
			var imgAr = resp.imageArr;	
			//ptInfo += '<div data-role="main" class="ui-content"><a class="userPost" data-id="'+resp.userId+'" data-name="'+resp.fullName+'">'+resp.fullName+'</a><div>'+resp.addDate+'</div><div class="space10"></div></div>';
			var msgblk = '';
			if(localStorage.getItem('userId') != resp.userId){
			msgblk = '<i onclick="openMsgModal()" style="color: #1595fb;" class="fa fa-envelope" aria-hidden="true"></i>';
			}
			
			var wishlist = '';			
			if(localStorage.getItem('userId') > 0 && localStorage.getItem('userId') != resp.userId){
				var fa = '';
				if(resp.isWish > 0){fa='fa-heart';}else{fa='fa-heart-o';}
			wishlist = '<a  href="#" onclick="AddWishlist('+localStorage.getItem('userId')+','+resp.pId+')"><i class="fa '+fa+' wishlist'+resp.pId+'" style="color: #1595fb;" aria-hidden="true"></i></a>';
			}
			
			ptInfo += '<div data-role="main" class="ui-content"><div class="row"><div class="col-xs-6"><a class="userPost" data-id="'+resp.userId+'" data-name="'+resp.fullName+'">'+resp.fullName+'</a><div>'+resp.addDate+'</div></div><div class="col-xs-6 text-right msgTxt">'+msgblk+'&nbsp;'+wishlist+'</div></div></div><div class="space10"></div>';
			
			ptInfo += '<div class="psDetImg"><div class="swiper-container"><div class="swiper-wrapper">';
			var sldCls = "";
			$.each( imgAr, function( i, item ) {
				//alert(i);
				sldCls = "";
				if (i == 0) {
					sldCls = "active";
				}
				ptInfo += '<div class="swiper-slide"><img data-u="image" src="'+SITE_DOMAIN+'postImages/'+resp.imgPath+'/'+item+'" /></div>';
			})
			ptInfo += '</div><div class="swiper-pagination"></div></div></div>';
			
			var Report = '';
			if(localStorage.getItem('userId') > 0 && localStorage.getItem('userId') != resp.userId){
				
				if(resp.report > 0){
					Report = 'Reported';
				}else{	
					Report = '<a href="#" data-toggle="modal" data-target="#Report">Report</a>';
				}
			}
			
			
			if (resp.title != "") {
			ptInfo += '<div class="ui-content"><div class="row"><div class="prPrice col-xs-6"><i class="fa fa-inr"></i>'+resp.price+'</div><div class="col-xs-6 text-right">'+Report+'</div><div class="col-xs-12"><strong>'+resp.title+'</strong></div></div>';
			}	
			if (resp.description != "") {
			ptInfo += '<div>'+resp.description+'</div>';
			}			
			
			var lik = ""; var lkcls = ""; var cmCnt = "";
			if (resp.cmtCount > 0) {cmCnt = resp.cmtCount;}
			if (resp.pLike > 0) {lik = resp.pLike;}
			
			var lkthmb = '<i class="fa fa-thumbs-o-up" aria-hidden="true"></i>';
			if (resp.isLike > 0) {
				lkcls = 'lkFtCor';
				lkthmb = '<i class="fa fa-thumbs-up" aria-hidden="true"></i>';
			}
			
			
			ptInfo += '<div class="shrIcn"><div class="likDis addLike '+lkcls+'" id="addLike-'+resp.pId+'">'+lkthmb+' <span>'+lik+'</span> Like</div><div class="comment" id="comment-'+resp.pId+'"><i class="fa fa-comments-o" aria-hidden="true"></i> <span>'+cmCnt+'</span> Comments</div><div class="clearfix"></div></div></div>';
				
			ptInfo += '<div class="divider" id="pstCmtbx"></div>';
			ptInfo += '<div data-role="main" class="ui-content"><h4>Add Comment</h4>';
			if (localStorage.getItem('userId') > 0) {
			ptInfo += '<div><textarea name="commentText" id="commentText" class="form-control ui-input-text ui-shadow-inset ui-body-inherit ui-corner-all ui-textinput-autogrow"></textarea><div class="space10"></div><div class="btn btn-success orgBtn" id="commentBtn" onclick="addComment('+resp.pId+')">Comment</div>';
			}else {
				ptInfo += '<div class="alert alert-info">Please login to add comment.</div>';
			}	
			ptInfo += '<div class="space10"></div><div id="ajxComnt"></div>';
			
			
			
			var postForm = '';
			if (resp.cmtCount > 0) {
				$.each( resp.comment, function( i, item ) {
					var rbt = '';
					if(localStorage.getItem('userId') == resp.userId){
					 rbt = '<div style="color: #1595fb;" class="text-right replybtn replybtn'+item.cId+'" onclick="toggleCReply('+item.cId+')">Replay</div>';
					 rbt += '<div style="height:5px;clear:both;"></div><div class="'+item.cId+' comRply" style="display:none;"><form name="post" id="form'+item.cId+'"><textarea name="comment" id="commentReply'+item.cId+'" class="form-control"></textarea><input type="hidden" name="commentId" id="commentId'+item.cId+'" value="'+item.cId+'" /><input type="hidden" name="userId" id="userId'+item.cId+'" value="'+localStorage.getItem('userId')+'" /><input type="hidden" name="postId" id="postId'+item.cId+'" value="'+item.pId+'" /><div style="height:5px;clear:both;"></div><input type="button" class="btn btn-success orgBtn" onclick="replyComment('+item.cId+')" value="Reply" />&nbsp;<input type="button" class="btn btn-success orgBtn" onclick="closeComment('+item.cId+')" value="Close" /></form></div>';
					}							
					
					var rComment = '';
					var loadReply = '';
					rComment += '<div class="cr'+item.cId+'"></div>';
					if(item.replyCount > 0){
						var cid = 0; 
						$.each(item.commentReply, function(i, item1) {
						rComment += '<div class="postUsr text-right">'+item1.fullName+' on '+item1.addDate+'</div><div class="text-right">'+item1.comment+'<div class="replyData'+item1.replyId+'"></div></div><div style="height:10px;clear:both;"></div>';
						cid = item1.replyId;
						});
						rComment += '<input name="commentReplylmt" id="commentReplylmt'+cid+'" value="5" type="hidden"/> <div id="loadMoreReply"></div><div class="cwaiting'+cid+' text-right" style="display:none;">Please Wait...</div><div class="text-right loadMoreReply'+cid+'" style="color: #1595fb;" onclick="loadMoreReply('+cid+')">Load More</div><div class="space10"></div>';
						
						loadReply = '<div class="loadReply'+cid+'"></div>';
					}
					
					
					ptInfo += '<div class="postUsr">'+item.fullName+' on '+item.addDate+'</div><div class="cmtTxt">'+item.comment+'<div class="replyData'+item.cId+'"></div>'+loadReply+rComment+rbt+'</div><div class="space10"></div>';					
				});
			}
			
				
			ptInfo += '<div id="allComnt"></div>';
			if (resp.cmtCount > 10) {
				ptInfo += '<a onclick="showMoreComent('+resp.pId+',\'loadmore\')" id="moreComment">View more comments</a>';
			}	
			ptInfo += '</div></div><div id="sendMsg" class="modal fade" role="dialog"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><a href="#" class="close" data-dismiss="modal">&times;</a><h4 class="modal-title">Send Message</h4></div><div class="modal-body"><div class="replyMsg1Err"></div><form method="post" name="replyMsgFrm1" id="replyMsgFrm1"><div class="msg-txt replyTxt"><textarea rows="5" placeholder="Message" class="form-control" id="replyMsg1" name="replyMsg"></textarea></div><input id="receiverId1" name="receiverId" class="yellow_button" value="'+resp.userId+'" type="hidden"><input id="sessionId1" name="sessionId" class="yellow_button" value="'+localStorage.getItem('userId')+'" type="hidden"><input id="fullName1" name="fullName" class="yellow_button" value="'+localStorage.getItem('fullName')+'" type="hidden"><div style="height:5px;clear:both;"></div><div class="msg-btn"><input id="replyBtn1" name="replyBtn" class="btn btn-success orgBtn" onclick="pMsg1()" value="Send" type="button"></div><div class="msg-btn loaderload" style="display:none;">Loading...</div></form></div></div></div></div>';
				
				
			ptInfo += '<div id="Report" class="modal fade" role="dialog"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><a href="#" class="close" data-dismiss="modal">&times;</a><h4 class="modal-title">Report Post</h4></div><div class="modal-body"><div class="ReportErr"></div><div style="height:5px;clear:both;"></div><form method="post" name="msgReply" id="msgReply"><textarea rows="5" name="reason" class="reportreason form-control" placeholder="Reason why reports"></textarea><input type="hidden" class="reportpostId" value="'+resp.pId+'" /><input type="hidden" class="reportuserId" value="'+localStorage.getItem('userId')+'" /><div style="height:5px;clear:both;"></div><div class="msg-btn"><input id="reportRason" name="reportRason" class="btn btn-success orgBtn" onclick="addRason()" value="Report" type="button"></div><div class="msg-btn Reportloaderload" style="display:none;">Loading...</div></form></div></div></div></div>';
			
			$('#postInfo').html(ptInfo);			
			$('#ajxLoading').hide();
			
			if (resp.title != "") {
				var ntfTitl = resp.title;
			}else if (resp.description != "") {
				var ntfTitl = resp.description;
			}
			
			var swiper = new Swiper('.swiper-container', {
		      slidesPerView: 1,
		      spaceBetween: 30,
		      loop: true,      
		      pagination: {
		        el: '.swiper-pagination',
		        clickable: true,
		      },
		      navigation: {
		        nextEl: '.swiper-button-next',
		        prevEl: '.swiper-button-prev',
		      },
		    });		
				},
				dataType: 'json',
				//async: false		
			});
	$.mobile.changePage( $("#postDetail"),{ transition: "fade"});
}	


function toggleCReply(id) {
	$('.replybtn').css({'display':'block'});
	$('.comRply').css({'display':'none'});
	$('.replybtn'+id).css({'display':'none'});
	$('.'+id).toggle('slow');
}

function closeComment(id) {
	$('.comRply').css({'display':'none'});
	$('.'+id).css({'display':'none'});
	$('.replybtn').css({'display':'block'});
}
			
function replyComment(id) {
	$('#ajxLoading').show();

	
	

	var cmt = $('#commentReply'+id).val();
	if(cmt == '') {
		$('#commentReply'+id).css({'border':'1px solid red'});
		$('#ajxLoading').hide();
		return fasle;
	}
	
	var commentReply = $('#commentReply'+id).val();
	var commentId = $('#commentId'+id).val(); 
	var userId = $('#userId'+id).val(); 
	var postId = $('#postId'+id).val();
	
	var formData = $('#form'+id).serialize();
	
	$.ajax({
		type: "POST",
		url: THIS_DOMAIN+"replyComment.php",
		data: {comment:commentReply, commentId:commentId, userId:userId, pId:postId},
		success: function(resp)
		{
			$('#commentReply'+id).val('');	
			console.log(resp)
			if(resp.result == 'success'){
				var d = new Date();
				var dat = '<div class="postUsr text-right">'+localStorage.getItem('fullName')+' on '+d.getDate()+'/'+(d.getMonth()+1)+'/'+d.getFullYear()+'</div><div class="text-right">'+commentReply+'<div class="replyData'+commentId+'"></div></div><div style="height:10px;clear:both;"></div>';
				
				
				$('.cr'+id).append(dat);
				$('html, body').animate({
			      scrollTop: $('.cr'+id).offset().top - 300
			    }, 500);
			}
			$('#ajxLoading').hide();
		},
		dataType: 'json',
		//async: false
	});
}

function addRason() {
	var reportpostId = $('.reportpostId').val();
	var reportuserId = $('.reportuserId').val();
	var reason = $('.reportreason').val();
	$('#ajxLoading').show();
	if(reason.trim() == '' ){
		$('.reportreason').css({'border':'1px solid red'});
		return false;
	}
	$.ajax({
		type: "POST",
		url: THIS_DOMAIN+"reportPost.php",
		data: {userId:reportuserId,postId:reportpostId,reason:reason},
		success: function(resp)
		{
			if(resp.result == 'success'){
				$('.ReportErr').html('Reported post successfully.').css({'color':'green'});
				$('.reportreason').val('');
			}
			$('#ajxLoading').hide();
		},
		dataType: 'json',
		//async: false
	});
}	

function onSuccess(result){
  //alert("Success:"+result);
}
 
function onError(result) {
  //alert("Error:"+result);
}

var smsd = {
    sendSms: function() {
        var number = '9588421767'; /* iOS: ensure number is actually a string */
        var message = 'check android';
       // console.log("number=" + number + ", message= " + message);

        //CONFIGURATION
        var options = {
            replaceLineBreaks: false, // true to replace \n by a new line, false by default
            android: {
                intent: 'INTENT'  // send SMS with the native android SMS messaging
                //intent: '' // send SMS without open any other app
            }
        };

        var success = function () { alert('Message sent successfully'); };
        var error = function (e) { alert('Message Failed:' + e); };
        sms.send(number, message, options, success, error);
    }
};

function showMoreComent(pId,clfr) {
	var ajxCmt = "";
	var cmlim = $('#commentlmt').val();
	$.ajax({
		type: "POST",
		url: THIS_DOMAIN+"getPostComment.php",
		data: {pId:pId,limt:cmlim},
		success: function(resp)
		{	
			//alert(resp)
			if (resp != "") {
				$.each( resp, function( i, item ) {
					ajxCmt += '<div class="postUsr">'+item.fullName+' on '+item.addDate+'</div><div class="cmtTxt">'+item.comment+'</div><div class="space10"></div>';								
				});
				if (resp[0].totRec < 10) {
					$('#moreComment').hide();
				}
			}
			
			$('#allComnt').append(ajxCmt);
			var pgLim = Number($('#commentlmt').val()) + 10;
			$('#commentlmt').val(pgLim);
		},
		dataType: 'json',
		//async: false		
	});
}	

function addComment(psId) {	
	var cmtxt = $.trim($('#commentText').val());	
	var uId = localStorage.getItem('userId');	
	var cmtData = {pId:psId, cmtxt:cmtxt, puId:uId, callFor:'comment'}
	if (cmtxt != "") {
		$('#ajxLoading').show();
		var ajxCmt = "";
		$.ajax({
			type: "POST",
			url: THIS_DOMAIN+"addPostComment.php",
			data: cmtData,
			success: function(resp)
			{	
				//alert(resp);
								
				if (resp != "") {
					ajxCmt += '<div class="postUsr">'+localStorage.getItem('fullName')+' on '+resp.addDate+'</div><div class="cmtTxt">'+resp.comment+'</div><div class="space10"></div>';
					$('#ajxComnt').prepend(ajxCmt);
					var cmct = $('#comment-'+psId+' span').text();
					cmct = Number(cmct) + 1;
					//alert(cmct);
					$('#comment-'+psId+' span').html(cmct);
					$('#commentText').val('');
				}
					
				$('#ajxLoading').hide();
				
			},
			dataType: 'json',		
		});
	}
}	
function onSuccess(imageURI) {
	var imgArrC = [];	
    var image = document.getElementById('myImage');
    image.src = imageURI;
    $('#imgPath').val(imageURI);
    imgArrC.push(imageURI);    
    localStorage.setItem("imgStor", JSON.stringify(imgArrC));
}

function uploadImage(imageURI) {
	//alert(imageURI);
	var options = new FileUploadOptions();
	 options.fileKey = "file";
	 options.fileName = imageURI.substr(imageURI.lastIndexOf('/') + 1);
	 //options.fileName = 'myImg.jpg';
	 options.mimeType = "image/jpeg";
	 
	 var params = new Object();
	 params.value1 = "test";
	 params.value2 = "param";
	 options.params = params;
	 options.chunkedMode = false;
	 
	 var ft = new FileTransfer();
	 ft.upload(imageURI, THIS_DOMAIN+"file-upload.php", function(result){
	  //var imgRes = JSON.stringify(result);
	  //return result.response;	  
	  $('#imgName').val(result.response);
	 }, function(error){
	  console.log(JSON.stringify(error));
	 }, options);	
}	

function onFail(message) {
    alert('Failed because: ' + message);
}

$(document).scroll(function(){
	if ($(this).scrollTop() > 100) {			
		$('.searchBx').css({"top": "0px",'position':'fixed','background':'#166bb3'});
	} else {
		$('.searchBx').css({"top": "0px",'position':'relative','background':'#166bb3'});
	}	
});

function goTocomment(ptId) {
	//alert(window.location.href)
	getPostDetail(ptId)
}	

function refreshPage()
{
	
    jQuery.mobile.changePage(window.location.href, {
        allowSamePageTransition: true,
        transition: 'none',
        reloadPage: true
    });
}

function saveRegId(regId) {
	//alert(regId)
	$.ajax({
		type: "POST",
		url: THIS_DOMAIN+"savePushReciver.php",
		data: {rId:regId},
		success: function(resp)
		{
			//alert(resp);		
		},
		dataType: 'json',
	});
}	

function checkLoginUser() {
	
	if (localStorage.getItem('userId') > 0) {
		$('.loginBtn').html('Logout').attr('href', '#logoutPage');
		var lgUM = localStorage.getItem('fullName');
		$('#lgUserName').html('Hi, '+lgUM);
		
		$('.welUser').css('display','block');
	}else {
		$('.loginBtn').html('Login').attr('href', '#loginPage');
		$('.welUser').css('display','none');		
	}
}
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
function openSearch() {
	$( ".topNavBar").hide();
	$( "#custom-search-input").show();
}
function closeSearch() {
	$( ".topNavBar").show();
	$( "#custom-search-input").hide();
}

function pMsg() {
	var replyMsg = $('#replyMsg').val();
	$('.loaderload').css({'display':'block'});
	$('#replyBtn').css({'display':'none'});
	
	if(replyMsg == ''){
		$('#replyMsg').css({'border':'1px solid red'});
		$('.loaderload').css({'display':'none'});
		$('#replyBtn').css({'display':'block'});
		return false;
	}	
	
	var sessionId = $("#sessionId").val();  
	var fullName = $("#fullName").val();      		
	var formValues = $("#replyMsgFrm").serialize();
		console.log(formValues);
		var newData = '';
		
		$.ajax({
		type: "POST",
		url: THIS_DOMAIN+"replyMsg.php",
		data: formValues,
		success: function(result)
		{
			//console.log(result);
			
			$('.loaderload').css({'display':'none'});
			$('#replyBtn').css({'display':'block'});
			$("#replyMsg").val('');
			
			newData += '<div class="row" style="border:1px solid #ddd;margin-left: 15px;margin-right: 15px;padding: 10px 0px 0px;"><div class="col-md-12"><a href="'+SITE_DOMAIN+'user/'+result.userSEOName+'">'+result.fullName+'</a></div><div class="space10"></div><div class="col-md-12"><p>'+result.message+'</p></div></div>';
			
			$("#replyDiv").append(newData);
				
		},
		dataType: 'json',
	});
}

function pMsg1() {
	var replyMsg = $('#replyMsg1').val();
	$('.loaderload').css({'display':'block'});
	$('#replyBtn1').css({'display':'none'});
	
	if(replyMsg == ''){
		$('#replyMsg1').css({'border':'1px solid red'});
		$('.loaderload').css({'display':'none'});
		$('#replyBtn1').css({'display':'block'});
		return false;
	}	
	
	var sessionId = $("#sessionId1").val();  
	var fullName = $("#fullName1").val();      		
	var formValues = $("#replyMsgFrm1").serialize();
		

		var newData = '';
		$.ajax({
			type: "POST",
			url: THIS_DOMAIN+"replyMsg.php",
			data: formValues,
			success: function(result)
			{
				$('.loaderload').css({'display':'none'});
				$('#replyBtn1').css({'display':'block'});
				$("#replyMsg1").val('');		
				$("#replyMsg1Err").html('Message sent successfully.').css({'color':'green','margin-bottom':'10px'});
			},
			dataType: 'json',
		});
}



function AddWishlist(userId,postId) {
	$.ajax({
		type: "POST",
		url: THIS_DOMAIN+"addWishlist.php",
		data: {userId:userId,postId:postId},
		success: function(result)
		{
			if(result.result == 'add'){
				$('.wishlist'+postId).addClass('fa-heart').removeClass('fa-heart-o');
			}
			if(result.result == 'remove'){
				$('.wishlist'+postId).addClass('fa-heart-o').removeClass('fa-heart');
				if($('.ui-page-active').attr('id') == 'wishlistPage'){
					$('.cardView'+postId).css({'display':'none'});
				}
			}
		},dataType: 'json',
	});	
}

function loadMoreReply(cId) {
	var limit = $('#commentReplylmt'+cId).val();
	$('.loadMoreReply'+cId).css({'display':'none'});
	$('.cwaiting'+cId).css({'display':'block'});
	
	$.ajax({
		type: "POST",
		url: THIS_DOMAIN+"loadmoreReply.php",
		data: {cId:cId,lmt:limit},
		success: function(result)
		{

			$('.loadMoreReply'+cId).css({'display':'block'});
			$('.cwaiting'+cId).css({'display':'none'});

			if(result != '' && result !==null && typeof result === "object"){
				$('#commentReplylmt'+cId).val(Number(limit) + 5);
				var rComment = '';
				$.each(result, function(i, item) {
					rComment += '<div class="postUsr text-right">'+item.fullName+' on '+item.addDate+'</div><div class="text-right">'+item.comment+'<div class="replyData'+item.cId+'"></div></div><div style="height:10px;clear:both;"></div>';
				});
				
				$('#loadMoreReply').append(rComment);

			}else{
				$('.loadMoreReply'+cId).css({'display':'none'});			
			}
		},dataType: 'json',
	});	
}

